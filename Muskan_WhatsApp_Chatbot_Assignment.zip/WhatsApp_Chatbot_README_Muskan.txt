# WhatsApp Chatbot Project (Java + Spring Boot + Firebase)

👩‍💻 **Developer:** Muskan Prajapati  
📅 **Project Type:** Internship / College Project  
🌐 **Tech Stack:** Java, Spring Boot, Firebase, REST API

---

## 📌 Project Overview

This project is a simple WhatsApp-style chatbot backend built using **Java** and **Spring Boot**. The chatbot receives messages through an API and replies based on basic logic. Messages are stored in **Firebase Realtime Database**.

The project is beginner-friendly and designed to show understanding of:
- Java OOP
- Spring Boot web services
- Firebase backend integration

---

## ⚙️ Technologies Used

- **Java 17+**
- **Spring Boot**
- **Firebase Admin SDK**
- **Postman** (for testing)
- **Maven** (for dependency management)

---

## 🚀 Features

- Simple chatbot logic (`hello`, `help`, `about`)
- Stores message logs in Firebase
- Exposes a REST API endpoint `/api/chat/message`
- Uses Firebase Admin SDK for backend storage
- Ready for deployment on services like Render or Heroku

---

## 📁 Folder Structure

```
whatsapp-chatbot/
├── src/
│   └── main/
│       ├── java/
│       │   └── com/muskan/chatbot/
│       │       ├── WhatsAppChatbotApplication.java
│       │       ├── controller/ChatController.java
│       │       └── firebase/FirebaseInitializer.java
│       └── resources/
│           ├── application.properties
│           └── serviceAccountKey.json (You must add your own)
├── pom.xml
```

---

## 📦 How to Run

1. Clone or unzip the project
2. Add your `serviceAccountKey.json` in `src/main/resources/` from Firebase Console
3. Run the project via IDE or using:

```
mvn spring-boot:run
```

4. Use Postman:
   - Method: POST
   - URL: `http://localhost:8080/api/chat/message`
   - Body: Raw Text (e.g., `hello`)

---

## 🧠 Sample Replies

- Input: `hello` → Bot: `Hi! I'm Muskan Prajapati's chatbot 😊`
- Input: `about` → Bot: `I am a chatbot made by Muskan using Java + Firebase + Spring Boot.`

---

## ✅ Status

Project completed and tested successfully by **Muskan Prajapati**.

