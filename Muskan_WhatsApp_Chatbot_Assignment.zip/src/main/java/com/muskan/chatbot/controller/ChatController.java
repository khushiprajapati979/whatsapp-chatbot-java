package com.muskan.chatbot.controller;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/chat")
public class ChatController {

    @PostMapping("/message")
    public String getReply(@RequestBody String message) {
        String reply;
        if (message.toLowerCase().contains("hello")) {
            reply = "Hi! I'm Muskan Prajapati's chatbot 😊";
        } else if (message.toLowerCase().contains("help")) {
            reply = "You can type: hello, help, or about.";
        } else if (message.toLowerCase().contains("about")) {
            reply = "I am a chatbot made by Muskan using Java + Firebase + Spring Boot.";
        } else {
            reply = "Sorry, I didn't understand that.";
        }

        DatabaseReference ref = FirebaseDatabase.getInstance().getReference("messages");
        Map<String, String> msg = new HashMap<>();
        msg.put("user", message);
        msg.put("bot", reply);
        ref.push().setValueAsync(msg);

        return reply;
    }
}
